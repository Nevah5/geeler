-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 16. Jun 2021 um 21:35
-- Server-Version: 10.3.27-MariaDB-0+deb10u1
-- PHP-Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `geeler`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `admin`
--

CREATE TABLE `admin` (
  `ID` int(11) NOT NULL,
  `login` tinyint(1) NOT NULL DEFAULT 1,
  `registration` tinyint(1) NOT NULL DEFAULT 1,
  `maintenance` tinyint(1) NOT NULL,
  `usernamechanging` tinyint(1) NOT NULL,
  `autoverify` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `admin`
--

INSERT INTO `admin` (`ID`, `login`, `registration`, `maintenance`, `usernamechanging`, `autoverify`) VALUES
(1, 1, 1, 0, 1, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cookielogin`
--

CREATE TABLE `cookielogin` (
  `ID` int(11) NOT NULL,
  `userID` text NOT NULL,
  `token` text NOT NULL,
  `IP` text NOT NULL,
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `cookielogin`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `reviews`
--

CREATE TABLE `reviews` (
  `ID` int(11) NOT NULL,
  `userID` text NOT NULL,
  `impression` text NOT NULL,
  `feedback` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `reviews`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `support`
--

CREATE TABLE `support` (
  `A_I` int(11) NOT NULL,
  `caseID` text DEFAULT NULL,
  `userID` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `state` tinytext DEFAULT NULL,
  `teamID` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `support`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `themes`
--

CREATE TABLE `themes` (
  `ID` int(11) NOT NULL,
  `postID` text NOT NULL COMMENT 'The md5-hash post-ID',
  `theme` text DEFAULT NULL,
  `type` text DEFAULT NULL COMMENT 'post/comment/like/dislike',
  `title` text DEFAULT NULL COMMENT 'title of post',
  `contents` text DEFAULT NULL COMMENT 'description/comment',
  `userID` text DEFAULT NULL COMMENT 'id of poster/commenter',
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted` text NOT NULL DEFAULT '0',
  `warned` text NOT NULL DEFAULT '0',
  `warnedby` text DEFAULT NULL,
  `edited` text NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `themes`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `users`
--

CREATE TABLE `users` (
  `A_I` int(11) NOT NULL,
  `ID` text NOT NULL,
  `Username` text NOT NULL,
  `Email` text NOT NULL,
  `Password` text NOT NULL,
  `Joindate` timestamp NOT NULL DEFAULT current_timestamp(),
  `Rank` text NOT NULL DEFAULT 'default',
  `Changed_Username` text DEFAULT '0',
  `Description` text DEFAULT NULL,
  `Themes_created` int(11) DEFAULT 0,
  `Posts_created` int(11) DEFAULT 0,
  `Experience` int(11) DEFAULT 0,
  `Verified` text DEFAULT 'no',
  `Banned` tinyint(1) DEFAULT 0,
  `last_IP` text DEFAULT NULL,
  `last_seen` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Avatar` text NOT NULL DEFAULT 'default.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `users`
--

INSERT INTO `users` (`A_I`, `ID`, `Username`, `Email`, `Password`, `Joindate`, `Rank`, `Changed_Username`, `Description`, `Themes_created`, `Posts_created`, `Experience`, `Verified`, `Banned`, `last_IP`, `last_seen`, `Avatar`) VALUES
(1, 'f8ecf2e', 'geeler_standart', 'standart@geeler.net', '$2y$10$MKoxmc7pEazpV8.Mu6WdDeXP3oROpm7.KtKT/VQ3V07a.AtA4NSuq', '2021-06-01 08:55:21', 'default', '0', NULL, 0, 0, 0, 'yes', 0, '213.55.225.162', '0000-00-00 00:00:00', 'default.png'),
(2, 'cf76fac0', 'geeler_admin', 'admin@geeler.net', '$2y$10$V4QGvlMHOIGbUDbSAl6cMeSeEBfA0G.cvnN0DHDhpqL3zUj/Cl4Mu', '2021-06-03 08:54:56', 'admin', '0', NULL, 0, 0, 0, 'yes', 0, NULL, '2021-06-03 08:56:30', 'admin.png'),
(3, '1fc5699', 'geeler_mod', 'mod@geeler.net', '$2y$10$2oa.t5IeEQCrlYtSPl3kUu1cZAPVV6zSPSTrvEY9qpvVCjXGZB1R.', '2021-06-04 07:37:29', 'mod', '0', NULL, 0, 0, 0, 'yes', 0, '213.55.225.200', '2021-06-04 08:09:13', 'admin.png'),
(4, '3230b74', 'geeler_verified', 'verified@geeler.net', '$2y$10$XTNCgbpBiSRYRXymzGulUu9B41xhToGuwkTPQhl10viwoLZEHpBdi', '2021-06-04 07:37:46', 'verified', '0', NULL, 0, 0, 0, 'yes', 0, NULL, '0000-00-00 00:00:00', 'admin.png');

------------------------------------------------
--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID`);

--
-- Indizes für die Tabelle `cookielogin`
--
ALTER TABLE `cookielogin`
  ADD PRIMARY KEY (`ID`);

--
-- Indizes für die Tabelle `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`ID`);

--
-- Indizes für die Tabelle `support`
--
ALTER TABLE `support`
  ADD PRIMARY KEY (`A_I`);

--
-- Indizes für die Tabelle `themes`
--
ALTER TABLE `themes`
  ADD PRIMARY KEY (`ID`);

--
-- Indizes für die Tabelle `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`A_I`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `admin`
--
ALTER TABLE `admin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT für Tabelle `cookielogin`
--
ALTER TABLE `cookielogin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=219;

--
-- AUTO_INCREMENT für Tabelle `reviews`
--
ALTER TABLE `reviews`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT für Tabelle `support`
--
ALTER TABLE `support`
  MODIFY `A_I` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT für Tabelle `themes`
--
ALTER TABLE `themes`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=190;

--
-- AUTO_INCREMENT für Tabelle `users`
--
ALTER TABLE `users`
  MODIFY `A_I` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
